package com.example.exp1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText input;
    TextView textView,output;
    Button button;
    RadioGroup radioGroup;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        output = findViewById(R.id.output);
        textView = findViewById(R.id.textView);
        input = findViewById(R.id.input);
        button= findViewById(R.id.button);
        radioGroup=findViewById(R.id.radioGroup);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convert();
            }
        });
    }

    private void convert() {
        int radioid = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioid);
        String i=input.getText().toString();
        double value = Double.parseDouble(i);
        if (radioButton==findViewById(R.id.itc)){
            output.setText(""+value*2.54+" Centimeter");
        }
        else if (radioButton==findViewById(R.id.ktm)){
            output.setText(""+value*1000+" Meter");
        }
        else if (radioButton==findViewById(R.id.ftc)){
            output.setText(""+((value-32)*5/9)+" Celsius");
        }
        else if (radioButton==findViewById(R.id.fti)){
            output.setText(""+value*12+" Inches");
        }
        else if (radioButton==findViewById(R.id.ltm)){
            output.setText(""+value*1000+" Mililitter");
        }
    }
}