package com.example.exp4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<String> ContactName =  new ArrayList<>(Arrays.asList("Hello","Hi"));
    List<String> ContactNumber =  new ArrayList<>(Arrays.asList("123","456"));

    Contact contact;
    Button add;
    EditText name,contactno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycleView);
        name=findViewById(R.id.name);
        contactno=findViewById(R.id.contactno);
        add=findViewById(R.id.add_contact);

        contact = new Contact(this,ContactName,ContactNumber);
        recyclerView.setAdapter(contact);
        recyclerView.setLayoutManager((new LinearLayoutManager(this)));

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String add_name=name.getText().toString();
                String add_no=contactno.getText().toString();
                ContactNumber.add(add_no);
                ContactName.add(add_name);
                name.setText("");
                contactno.setText("");
                contact.notifyDataSetChanged();
            }
        });

    }
}