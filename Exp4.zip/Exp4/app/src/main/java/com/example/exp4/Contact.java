package com.example.exp4;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Contact extends RecyclerView.Adapter<ContactViewHolder> {
    List<String> NameList,NumberList;
    public Contact(Context context,List<String> ContactName, List <String> ContactNumber){
        this.NameList=ContactName;
        this.NumberList=ContactNumber;
    }
    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact,parent,false);
        return new ContactViewHolder(view,NumberList);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
    holder.contactNumber.setText(NumberList.get(position));
    holder.contactName.setText(NameList.get(position));

    }

    @Override
    public int getItemCount() {
        return NumberList.size();
    }
}
class ContactViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    private List<String> numberList;
    TextView contactName, contactNumber;
    public ContactViewHolder(@NonNull View itemView,List<String> numberList) {
        super(itemView);
        itemView.setOnClickListener(this);
        contactName=itemView.findViewById(R.id.contactName);
        contactNumber=itemView.findViewById(R.id.contactNumber);
        this.numberList=numberList;
    }

    @Override
    public void onClick(View view) {
        int position =getLayoutPosition();
        String element = numberList.get(position);
        Context context= view.getContext();
        context.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+element)));
    }
}
