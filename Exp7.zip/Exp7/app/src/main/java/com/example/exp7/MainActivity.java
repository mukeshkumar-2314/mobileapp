package com.example.exp7;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    Button download;
    ImageView download_img;
    InputStream is = null;
    Bitmap bmImg = null;
    ProgressDialog p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        download = findViewById(R.id.Download);
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AsyncTaskExample asyncTask = new AsyncTaskExample();
                asyncTask.execute("https://wallpapercave.com/wp/wp6389512.jpg");
            }
        });
    }

    private class AsyncTaskExample extends AsyncTask<String, String, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... strings) {
            try{

                download_img = findViewById(R.id.download_img);
                URL ImageUrl = new URL(strings[0]);
                HttpURLConnection conn = (HttpURLConnection)ImageUrl.openConnection();
                conn.setDoInput(true);
                conn.connect();
                is=conn.getInputStream();
                bmImg=BitmapFactory.decodeStream(is);

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return bmImg;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p = new ProgressDialog(MainActivity.this);
            p.setMessage("Please wait... It is downloading");
            p.setIndeterminate(false);
            p.setCancelable(false);
            p.show();
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if(download_img!=null){
                p.hide();
                download_img.setImageBitmap(bitmap);
            }
            else {
                p.show();
            }
        }
    }
}