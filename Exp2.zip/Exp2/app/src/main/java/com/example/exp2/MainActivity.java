package com.example.exp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText name,regno,cgpa;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=findViewById(R.id.name);
        regno=findViewById(R.id.regno);
        cgpa=findViewById(R.id.cgpa);
        button=findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                String n= name.getText().toString();
                String r= regno.getText().toString();
                String c= cgpa.getText().toString();

                Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                intent.putExtra("name",n);
                intent.putExtra("regno",r);
                intent.putExtra("cgpa",c);
                startActivity(intent);
            }
        });
    }
}