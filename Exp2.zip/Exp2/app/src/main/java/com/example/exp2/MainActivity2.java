package com.example.exp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView name2,regno2,cgpa2;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        name2=findViewById(R.id.name2);
        regno2=findViewById(R.id.regno2);
        cgpa2=findViewById(R.id.cgpa2);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String regno = intent.getStringExtra("regno");
        String cgpa = intent.getStringExtra("cgpa");

        name2.setText("Name: "+name);
        regno2.setText("RegNo: "+regno);
        cgpa2.setText("CGPA: "+cgpa);

        button2=findViewById(R.id.button2);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){

                Intent intent = new Intent(MainActivity2.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
}